(() => {
  'use strict';

  if (document.getElementById('mfh-panel')) return;

  // ─── Student name detection ────────────────────────────────────────────

  function extractStudentName() {
    for (const h2 of document.querySelectorAll('h2')) {
      const m = h2.textContent.match(/Grading\s+for\s+(.+)/i);
      if (m) return m[1].trim();
    }
    return null;
  }

  // ─── Background messaging ──────────────────────────────────────────────
  // background.js holds the directory handle and returns matched file data
  // as {name, type, buffer} objects (ArrayBuffer is structured-cloneable).

  function requestFiles(studentName) {
    return new Promise(resolve => {
      chrome.runtime.sendMessage(
        { action: 'getFiles', studentName },
        response => resolve(response ?? { error: 'no_response' })
      );
    });
  }

  // ─── Moodle drop-zone injection ────────────────────────────────────────

  function getMoodleDropZone() {
    const selectors = [
      '.assignfeedback_file .filemanager',
      '[data-region="file-upload-drop-zone"]',
      '.filemanager .fm-empty-container',
      '.filemanager .fp-content',
      '.moodle-filepicker',
      '.fp-content',
    ];
    return selectors.map(s => document.querySelector(s)).find(Boolean) ?? null;
  }

  async function injectFileIntoMoodle(file) {
    const zone = getMoodleDropZone();
    if (!zone) return false;
    const dt = new DataTransfer();
    dt.items.add(file);
    for (const type of ['dragenter', 'dragover', 'drop']) {
      zone.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt }));
    }
    return true;
  }

  // ─── Panel UI ──────────────────────────────────────────────────────────

  const $ = id => document.getElementById(id);

  function setStatus(msg, type = 'info') {
    const el = $('mfh-status');
    if (el) { el.textContent = msg; el.dataset.type = type; }
  }

  function fileIcon(name) {
    const ext = (name.split('.').pop() ?? '').toLowerCase();
    return {
      pdf: '📄', doc: '📝', docx: '📝', odt: '📝',
      txt: '📃', rtf: '📃',
      png: '🖼️', jpg: '🖼️', jpeg: '🖼️',
      mp3: '🎵', m4a: '🎵', wav: '🎵',
      mp4: '🎬', mov: '🎬',
      zip: '📦',
    }[ext] ?? '📎';
  }

  function renderFiles(files) {
    const list = $('mfh-file-list');
    if (!list) return;
    list.innerHTML = '';

    if (!files.length) {
      list.innerHTML = '<div class="mfh-empty">No matching files found</div>';
      return;
    }

    files.forEach(({ name, type, buffer }) => {
      // Reconstruct a proper File object from the ArrayBuffer sent by background.js
      const file = new File([buffer], name, { type });

      const row = document.createElement('div');
      row.className = 'mfh-file';
      row.draggable = true;
      row.title = 'Drag onto Moodle upload area, or click Upload →';
      row.innerHTML = `
        <span class="mfh-file-icon">${fileIcon(name)}</span>
        <span class="mfh-file-name" title="${name}">${name}</span>
        <button class="mfh-inject-btn" title="Send to upload area">Upload →</button>
      `;

      row.addEventListener('dragstart', e => {
        e.dataTransfer.items.add(file);
        e.dataTransfer.effectAllowed = 'copy';
        row.classList.add('mfh-dragging');
      });
      row.addEventListener('dragend', () => row.classList.remove('mfh-dragging'));

      row.querySelector('.mfh-inject-btn').addEventListener('click', async e => {
        e.stopPropagation();
        setStatus('Sending to upload area…');
        const ok = await injectFileIntoMoodle(file);
        setStatus(
          ok ? '✓ File sent to upload area' : '✗ Drop zone not found — try dragging',
          ok ? 'ok' : 'warn'
        );
      });

      list.appendChild(row);
    });
  }

  async function refresh() {
    const studentName = extractStudentName();
    if (!studentName) { setStatus('No student name detected', 'warn'); return; }

    $('mfh-student').textContent = studentName;
    setStatus('Searching…');

    const result = await requestFiles(studentName);

    if (result.error === 'no_folder') {
      setStatus('No folder selected — click the extension icon', 'warn');
      return;
    }
    if (result.error === 'need_permission') {
      setStatus('Folder access expired — reselect in extension popup', 'warn');
      return;
    }
    if (result.error) {
      setStatus(`Error: ${result.error}`, 'error');
      return;
    }

    renderFiles(result.files);
    const n = result.files.length;
    setStatus(n ? `${n} file${n > 1 ? 's' : ''} found` : 'No matching files', n ? 'ok' : 'warn');
  }

  function buildPanel() {
    const panel = document.createElement('div');
    panel.id = 'mfh-panel';
    panel.innerHTML = `
      <div id="mfh-header">
        <span class="mfh-title">📎 Feedback Helper</span>
        <button id="mfh-collapse" title="Collapse">−</button>
      </div>
      <div id="mfh-body">
        <div id="mfh-student-row">
          <span class="mfh-label">Student</span>
          <span id="mfh-student">—</span>
        </div>
        <div id="mfh-file-list"></div>
        <div id="mfh-toolbar">
          <button id="mfh-refresh-btn" title="Refresh file list">↺ Refresh</button>
        </div>
        <div id="mfh-status"></div>
      </div>
    `;
    document.body.appendChild(panel);

    let collapsed = false;
    $('mfh-collapse').addEventListener('click', () => {
      collapsed = !collapsed;
      $('mfh-body').style.display = collapsed ? 'none' : '';
      $('mfh-collapse').textContent = collapsed ? '+' : '−';
    });

    $('mfh-refresh-btn').addEventListener('click', refresh);

    makeDraggable(panel, $('mfh-header'));
  }

  function makeDraggable(panel, handle) {
    let ox = 0, oy = 0, startX = 0, startY = 0;
    handle.style.cursor = 'grab';

    handle.addEventListener('mousedown', e => {
      if (e.target.id === 'mfh-collapse') return;
      startX = e.clientX; startY = e.clientY;
      const rect = panel.getBoundingClientRect();
      ox = rect.left; oy = rect.top;
      handle.style.cursor = 'grabbing';

      const move = ev => {
        panel.style.left = `${ox + ev.clientX - startX}px`;
        panel.style.top = `${oy + ev.clientY - startY}px`;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
      };
      const up = () => {
        handle.style.cursor = 'grab';
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
  }

  // ─── Message listener ─────────────────────────────────────────────────
  // 'refresh'        → called by popup after a new folder is selected
  // 'getStudentName' → called by popup on open to show who's being graded

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'refresh') { refresh(); return; }
    if (msg.action === 'getStudentName') {
      sendResponse({ name: extractStudentName() });
      return true;
    }
  });

  // ─── Init ──────────────────────────────────────────────────────────────

  async function init() {
    if (!extractStudentName()) return; // only activate on grading pages
    buildPanel();
    await refresh();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
